<?php
$servername = "localhost";
$username = "root";
$password = "subhanMySql1";
$dbname = "real_estate_database";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}else{ 

	$id = $_POST['id']; // Retrieve id data sent via AJAX
	$query = "SELECT * FROM property WHERE property_id='$id'";
	$result = mysqli_query($conn, $query); // Show property data with the id
	$row = mysqli_num_rows($result); // Calculate how much data from the $result execution results
	if($row > 0){ // If the data is more than 0
	  $data = mysqli_fetch_array($result); // take the property's data
	  
	  // BUat sebuah array
	  $callback = array(
	    'status' => 'success', // Set array status with success
	    'address' => $data['address'], // Set the address array with the contents of the address field in the property table
	    'total_sf' => $data['total_sf'], // Set the total_sf array with the contents of the total_sf field in the property table
	    'total_acr' => $data['total_acr'], // Set the total_acr array with the contents of the total_acr field in the property table
	    'year_contstructed' => $data['year_contstructed'], // Set the year_contstructed array with the contents of the year_contstructed field in the property table
	    'last_sold_date' => $data['last_sold_date'], // Set the last_sold_date array with the contents of the last_sold_date field in the property table
	    'last_appraisal_value' => $data['last_appraisal_value'], // Set the last_appraisal_value array with the contents of the last_appraisal_value field in the property table
	    'floors' => $data['floors'], // Set the floors array with the contents of the floors field in the property table


	  );
	}else{
	  $callback = array('status' => 'failed'); // set the status array with failed
	}
	echo json_encode($callback); // converting varibel $callback to JSON

	$conn->close();
}
?>